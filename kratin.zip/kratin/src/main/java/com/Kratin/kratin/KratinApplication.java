package com.Kratin.kratin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KratinApplication {

	public static void main(String[] args) {
		SpringApplication.run(KratinApplication.class, args);
	}

}
