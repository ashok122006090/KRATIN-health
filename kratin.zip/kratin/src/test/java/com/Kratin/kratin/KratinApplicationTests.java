package com.Kratin.kratin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KratinApplicationTests {

	@Test
	void contextLoads() {
	}

}
